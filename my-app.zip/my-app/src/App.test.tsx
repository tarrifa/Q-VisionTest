import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import App from './App';
import '@testing-library/jest-dom/extend-expect';

describe('Todo App', () => {
  test('Agregar tarea', () => {
    render(<App />);

    const inputElement = screen.getByPlaceholderText('Enter task name');
    const addButtonElement = screen.getByText('Add Task');

    // Ingresar el nombre de la tarea en el campo de entrada
    fireEvent.change(inputElement, { target: { value: 'Nueva tarea' } });

    // Hacer clic en el botón de agregar tarea
    fireEvent.click(addButtonElement);

    // Verificar que la tarea se haya agregado correctamente
    expect(screen.getByText('Nueva tarea')).toBeInTheDocument();
  });

  test('Marcar tarea como completada', async () => {
    render(<App />);
    
    const inputElement = screen.getByPlaceholderText('Enter task name');
    const addButtonElement = screen.getByText('Add Task');
    
    // Agregar una tarea
    fireEvent.change(inputElement, { target: { value: 'Nueva tarea' } });
    fireEvent.click(addButtonElement);
    
    // Esperar a que se actualice el DOM después de agregar la tarea
    await waitFor(() => screen.getByText('Nueva tarea'));
    
    const checkboxElement = screen.getByLabelText('Nueva tarea') as HTMLInputElement;
    
    // Marcar la tarea como completada
    fireEvent.click(checkboxElement);
    
    // Verificar que la tarea se haya marcado como completada
    expect(checkboxElement.checked).toBe(true);
    expect(screen.getByText('Nueva tarea')).toHaveStyle('text-decoration: line-through');
  });

  test('Eliminar tarea', () => {
    render(<App />);

    const inputElement = screen.getByPlaceholderText('Enter task name');
    const addButtonElement = screen.getByText('Add Task');

    // Agregar una tarea
    fireEvent.change(inputElement, { target: { value: 'Nueva tarea' } });
    fireEvent.click(addButtonElement);

    const deleteButtonElement = screen.getByText('Delete');

    // Eliminar la tarea
    fireEvent.click(deleteButtonElement);

    // Verificar que la tarea se haya eliminado correctamente
    expect(screen.queryByText('Nueva tarea')).toBeNull();
  });
});
