import { invertirLetras, encontrarNumeroMasGrande, sumarNumerosPares, ordenarPorPropiedad, Persona } from './Ejercicios';

describe('invertirLetras', () => {
  it('debe invertir las letras de una cadena de texto', () => {
    const cadenaOriginal = 'Hola mundo';
    const cadenaInvertida = 'odnum aloH';
    expect(invertirLetras(cadenaOriginal)).toEqual(cadenaInvertida);
  });
});

describe('encontrarNumeroMasGrande', () => {
  it('debe encontrar el número más grande en un arreglo de números', () => {
    const numeros = [1, 3, 5, 2, 4];
    const numeroMasGrande = 5;
    expect(encontrarNumeroMasGrande(numeros)).toEqual(numeroMasGrande);
  });

  it('debe lanzar un error si el arreglo está vacío', () => {
    const numeros = [];
    expect(() => encontrarNumeroMasGrande(numeros)).toThrow('El arreglo está vacío');
  });
});

describe('sumarNumerosPares', () => {
  it('debe sumar los números pares en un arreglo de números', () => {
    const numeros = [1, 2, 3, 4, 5, 6];
    const sumaNumerosPares = 12;
    expect(sumarNumerosPares(numeros)).toEqual(sumaNumerosPares);
  });
});

describe('ordenarPorPropiedad', () => {
  const personas: Persona[] = [
    { nombre: 'Ana', edad: 25 },
    { nombre: 'Pedro', edad: 20 },
    { nombre: 'María', edad: 30 },
  ];

  test('Ordenar por edad', () => {
    const resultado = ordenarPorPropiedad(personas, 'edad');
    expect(resultado).toEqual([
      { nombre: 'Pedro', edad: 20 },
      { nombre: 'Ana', edad: 25 },
      { nombre: 'María', edad: 30 },
    ]);
  });

  test('Ordenar por nombre', () => {
    const resultado = ordenarPorPropiedad(personas, 'nombre');
    expect(resultado).toEqual([
      { nombre: 'Ana', edad: 25 },
      { nombre: 'María', edad: 30 },
      { nombre: 'Pedro', edad: 20 },
    ]);
  });
});