export const invertirLetras=(cadena: string): string =>{
  return cadena.split('').reverse().join('');
}

export const encontrarNumeroMasGrande=(arr: number[]): number=> {
  if (arr.length === 0) {
    throw new Error("El arreglo está vacío");
  }

  let max = arr[0];

  for (let i = 1; i < arr.length; i++) {
    if (arr[i] > max) {
      max = arr[i];
    }
  }

  return max;
}

export const sumarNumerosPares = (arr: number[]): number =>{
  let suma = 0;

  for (let i = 0; i < arr.length; i++) {
    if (arr[i] % 2 === 0) {
      suma += arr[i];
    }
  }

  return suma;
}

export interface Persona {
  nombre: string;
  edad: number;
}

export const ordenarPorPropiedad = (arr: Persona[], propiedad: keyof Persona): Persona[] => {
  return arr.sort((a, b) => {
    if (a[propiedad] < b[propiedad]) {
      return -1;
    }
    if (a[propiedad] > b[propiedad]) {
      return 1;
    }
    return 0;
  });
};

