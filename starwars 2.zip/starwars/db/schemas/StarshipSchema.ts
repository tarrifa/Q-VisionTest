export const StarshipSchema: Realm.ObjectSchema = {
    name: 'Starship',
    properties: {
      name: 'string',
      model: 'string',
      manufacturer: 'string',
      cost_in_credits: 'string',
      length: 'string',
      crew: 'string',
      passengers: 'string',
    },
  };
  