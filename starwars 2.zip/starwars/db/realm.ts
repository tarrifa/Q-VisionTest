import Realm from 'realm';
import { PersonSchema} from './schemas/PersonSchema';
import { SpeciesSchema} from './schemas/SpeciesSchema';
import { PlanetSchema} from './schemas/PlanetSchema';
import { StarshipSchema} from './schemas/StarshipSchema';
import { VehicleSchema} from './schemas/VehicleSchema';

const realmConfig = {
    schema: [PersonSchema, PlanetSchema, VehicleSchema, StarshipSchema, SpeciesSchema],
  };
  

const realm = new Realm(realmConfig);

export default realm;