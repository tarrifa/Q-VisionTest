import { configureStore, ThunkAction, Action } from '@reduxjs/toolkit';
import swapiReducer from './slices/swapiSlicer';

export const store = configureStore({
  reducer: {
    swapi: swapiReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export type AppThunk<ReturnType = any> = ThunkAction<ReturnType, RootState, unknown, Action<string>>;
