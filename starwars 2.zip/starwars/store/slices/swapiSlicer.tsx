import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { AppThunk } from "../store";

interface SwapiState {
  loading: boolean;
  data: any | null;
  error: string | null;
}

const initialState: SwapiState = {
  loading: false,
  data: null,
  error: null,
};

const swapiSlice = createSlice({
  name: "swapi",
  initialState,
  reducers: {
    fetchSwapiRequest: (state) => {
      state.loading = true;
      state.error = null;
    },
    fetchSwapiSuccess: (state, action: PayloadAction<any>) => {
      state.loading = false;
      state.data = action.payload;
    },
    fetchSwapiFailure: (state, action: PayloadAction<string>) => {
      state.loading = false;
      state.error = action.payload;
    },
  },
});

export const { fetchSwapiRequest, fetchSwapiSuccess, fetchSwapiFailure } =
  swapiSlice.actions;

export default swapiSlice.reducer;

export const fetchPeopleData = (): AppThunk => async (dispatch) => {
  try {
    dispatch(fetchSwapiRequest());
    const response = await fetch("https://swapi.dev/api/people");
    const people = await response.json();
    dispatch(fetchSwapiSuccess(people));
  } catch (error) {
    dispatch(fetchSwapiFailure(error.message));
  }
};

export const fetchPlanetsData = (): AppThunk => async (dispatch) => {
  try {
    dispatch(fetchSwapiRequest());
    const response = await fetch("https://swapi.dev/api/planets");
    const planets = await response.json();
    dispatch(fetchSwapiSuccess(planets));
  } catch (error) {
    dispatch(fetchSwapiFailure(error.message));
  }
};
export const fetchSpeciesData = (): AppThunk => async (dispatch) => {
  try {
    dispatch(fetchSwapiRequest());
    const response = await fetch("https://swapi.dev/api/species");
    const species = await response.json();
    dispatch(fetchSwapiSuccess(species));
  } catch (error) {
    dispatch(fetchSwapiFailure(error.message));
  }
};
export const fetchStarshipsData = (): AppThunk => async (dispatch) => {
  try {
    dispatch(fetchSwapiRequest());
    const response = await fetch("https://swapi.dev/api/starships");
    const starships = await response.json();
    dispatch(fetchSwapiSuccess(starships));
  } catch (error) {
    dispatch(fetchSwapiFailure(error.message));
  }
};
export const fetchVehiclesData = (): AppThunk => async (dispatch) => {
  try {
    dispatch(fetchSwapiRequest());
    const response = await fetch("https://swapi.dev/api/vehicles");
    const vehicles = await response.json();
    dispatch(fetchSwapiSuccess(vehicles));
  } catch (error) {
    dispatch(fetchSwapiFailure(error.message));
  }
};
export const fetchSwapiData = (): AppThunk => async (dispatch) => {
  try {
    const categories = [
      "people",
      "starships",
      "planets",
      "vehicles",
      "species",
    ];
    dispatch(fetchSwapiRequest());

    const fetchDataPromises = categories.map(async (category) => {
      const response = await fetch(`https://swapi.dev/api/${category}`);
      const data = await response.json();
      return data.results.map((entry) => ({ ...entry, category }));
    });

    const fetchedData = await Promise.all(fetchDataPromises);
    const mergedData = fetchedData.flat();

    dispatch(fetchSwapiSuccess(mergedData));
  } catch (error) {
    dispatch(fetchSwapiFailure(error.message));
  }
};

