import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#000000",
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 16,
    marginTop:30,
  },
  card: {
    width: 300,
    padding: 16,
    borderRadius: 8,
    backgroundColor: "#FFFFFF",
    marginBottom: 16,
    alignItems: "center",
  },
  cardContent: {
    alignItems: "center",
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 8,
  },
  loadingText: {
    color: "#FFFFFF",
  },
  errorText: {
    color: "#FF0000",
  },
  input: {
    backgroundColor: "#FFFFFF",
    width: "80%", 
    padding: 8,
    marginBottom: 16,
  },
  buttonContainer: {
    justifyContent: "center",
    alignItems: "center",
    width: "100%",
  },
  button: {
    width:140,
    paddingVertical: 12,
    paddingHorizontal: 24,
    marginBottom: 8,
    backgroundColor: "#FFD700",
    borderColor: "#FFD700",
    color: "#000000",
  },
});
