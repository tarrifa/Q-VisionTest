import React, { useEffect } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { fetchVehiclesData } from '../../store/slices/swapiSlicer';
import { RootState } from '../../store/store';
import {styles} from '../../style/style'
import { Card } from '@rneui/base';

export type VehiclesProps = {
}

const Vehicles: React.FC<VehiclesProps> = () => {
	const dispatch = useDispatch();
	const { loading, data, error } = useSelector((state: RootState) => state.swapi);
  

  useEffect(() => {
    dispatch(fetchVehiclesData());
  }, [dispatch]);

  if (loading) {
    return <Text>Loading...</Text>;
  }

  if (error) {
    return <Text>Error: {error}</Text>;
  }

	return (
<ScrollView>
      <View style={styles.container}>

      <Text style={styles.title}>People</Text>
      {data &&
        data.results &&
        data.results.map((vehicles: any) => (
          <Card containerStyle={styles.card} key={vehicles.name}>
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>{vehicles.name}</Text>
              <Text>Model: {vehicles.model}</Text>
              <Text>Manufacturer: {vehicles.manufacturer}</Text>
              <Text>Cost: {vehicles.cost_in_credits}</Text>
              <Text>Length: {vehicles.length}</Text>
              <Text>Crew: {vehicles.crew}</Text>
              <Text>Passengers: {vehicles.passengers}</Text>
            </View>
          </Card>
        ))}
        </View>
    </ScrollView>
	);
};

export default Vehicles;
