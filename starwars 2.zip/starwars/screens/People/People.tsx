import React, { useEffect } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { fetchPeopleData } from '../../store/slices/swapiSlicer';
import { RootState } from '../../store/store';
import { styles } from '../../style/style';
import { Card } from '@rneui/base';

export type PeopleProps = {};

const People: React.FC<PeopleProps> = () => {
  const dispatch = useDispatch();
  const { loading, data, error } = useSelector((state: RootState) => state.swapi);

  useEffect(() => {
    dispatch(fetchPeopleData());
  }, [dispatch]);

  if (loading) {
    return <Text style={styles.loadingText}>Loading...</Text>;
  }

  if (error) {
    return <Text style={styles.errorText}>Error: {error}</Text>;
  }

  return (
    <ScrollView>
      <View style={styles.container}>

      <Text style={styles.title}>People</Text>
      {data &&
        data.results &&
        data.results.map((person: any) => (
          <Card containerStyle={styles.card} key={person.name}>
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>{person.name}</Text>
              <Text>Height: {person.height}</Text>
              <Text>Mass: {person.mass}</Text>
              <Text>Hair Color: {person.hair_color}</Text>
              <Text>Skin Color: {person.skin_color}</Text>
              <Text>Eye Color: {person.eye_color}</Text>
              <Text>Birth Year: {person.birth_year}</Text>
            </View>
          </Card>
        ))}
        </View>
    </ScrollView>
  );
};

export default People;
