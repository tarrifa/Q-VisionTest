import React, { useEffect } from "react";
import { View, Text, ScrollView } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { fetchPlanetsData } from "../../store/slices/swapiSlicer";
import { RootState } from "../../store/store";
import { styles } from "../../style/style";
import { Card } from "@rneui/base";

export type PlanetProps = {};

const Planets: React.FC<PlanetProps> = () => {
  const dispatch = useDispatch();
  const { loading, data, error } = useSelector(
    (state: RootState) => state.swapi
  );

  useEffect(() => {
    dispatch(fetchPlanetsData());
  }, [dispatch]);

  if (loading) {
    return <Text>Loading...</Text>;
  }

  if (error) {
    return <Text>Error: {error}</Text>;
  }

  return (
    <ScrollView>
      <View style={styles.container}>
        <Text style={styles.title}>People</Text>
        {data &&
          data.results &&
          data.results.map((planet: any) => (
            <Card containerStyle={styles.card} key={planet.name}>
              <View style={styles.cardContent}>
                <Text style={styles.cardTitle}>{planet.name}</Text>
                <Text>Rotation Period: {planet.rotation_period}</Text>
                <Text>Orbital Period: {planet.orbital_period}</Text>
                <Text>Diameter: {planet.diameter}</Text>
                <Text>Climate: {planet.climate}</Text>
                <Text>Gravity: {planet.gravity}</Text>
                <Text>Population: {planet.population}</Text>
              </View>
            </Card>
          ))}
      </View>
    </ScrollView>
  );
};

export default Planets;
