import React, { startTransition, useEffect } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { fetchStarshipsData } from '../../store/slices/swapiSlicer';
import { RootState } from '../../store/store';
import {styles} from '../../style/style'
import { Card } from '@rneui/base';

export type StarshipsProps = {
}

const Starships: React.FC<StarshipsProps> = () => {
	const dispatch = useDispatch();
	const { loading, data, error } = useSelector((state: RootState) => state.swapi);
  

  useEffect(() => {
    dispatch(fetchStarshipsData());
  }, [dispatch]);

  if (loading) {
    return <Text>Loading...</Text>;
  }

  if (error) {
    return <Text>Error: {error}</Text>;
  }

	return (
<ScrollView>
      <View style={styles.container}>

      <Text style={styles.title}>Starships</Text>
      {data &&
        data.results &&
        data.results.map((starship: any) => (
          <Card containerStyle={styles.card} key={starship.name}>
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>{starship.name}</Text>
              <Text>Model: {starship.model}</Text>
              <Text>Manufacturer: {starship.manufacturer}</Text>
              <Text>Cost: {starship.cost_in_credits}</Text>
              <Text>Length: {starship.length}</Text>
              <Text>Crew: {starship.crew}</Text>
              <Text>Passengers: {starship.passengers}</Text>
            </View>
          </Card>
        ))}
        </View>
    </ScrollView>
	);
};

export default Starships;
