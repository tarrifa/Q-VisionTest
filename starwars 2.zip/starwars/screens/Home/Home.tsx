import React, { useEffect, useState } from "react";
import { TextInput, View, Text, SafeAreaView, StyleSheet } from "react-native";
import { fetchSwapiData } from "../../store/slices/swapiSlicer";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../store/store";
import { Button } from "@rneui/base";
import { useNavigation } from "@react-navigation/native";
import {styles} from '../../style/style'
export type HomeProps = {};

const Home: React.FC<HomeProps> = () => {
  const { loading, data, error } = useSelector(
    (state: RootState) => state.swapi
  );
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [filteredData, setFilteredData] = useState<any[]>([]);
  const dispatch = useDispatch();
  const navigation = useNavigation();
  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  useEffect(() => {
    dispatch(fetchSwapiData());
  }, []);

  useEffect(() => {
    if (data && Array.isArray(data)) {
      const filtered = data.filter((item: any, index: number, array: any[]) => {
        const name = item.name || item.title || "";
        const category = item.category || "";
        const lowerCaseSearchQuery = searchQuery.toLowerCase();
        return (
          (name.toLowerCase().includes(lowerCaseSearchQuery) ||
            category.toLowerCase().includes(lowerCaseSearchQuery)) &&
          array.findIndex((i: any) => i.category === item.category) === index
        );
      });
      setFilteredData(filtered);
    }
  }, [data, searchQuery]);

  const handleCategory = (category: string) => {
    const categoryName = category.charAt(0).toUpperCase() + category.slice(1);
    navigation.navigate(categoryName);
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Star Wars Directory</Text>
      <TextInput
        style={styles.input}
        placeholder="Search by name or category"
        onChangeText={handleSearch}
      />
      {loading ? (
        <Text style={{color:"#fff"}}>Loading...</Text>
      ) : error ? (
        <Text>Error: {error}</Text>
      ) : (
        <View style={styles.buttonContainer}>
          {filteredData.length === 0 ? (
            <Text>No results found.</Text>
          ) : (
            filteredData.map((item: any) => (
              <Button
                key={item.url}
                onPress={() => handleCategory(item.category)}
                buttonStyle={styles.button}
              >
                {item.category || item.title}
              </Button>
            ))
          )}
        </View>
      )}
    </SafeAreaView>
  );
};


export default Home;
