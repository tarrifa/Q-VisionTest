import React, { useEffect } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { fetchSpeciesData } from '../../store/slices/swapiSlicer';
import { RootState } from '../../store/store';
import {styles} from '../../style/style'
import { Card } from '@rneui/base';

export type SpeciesProps = {
}

const Species: React.FC<SpeciesProps> = () => {
	const dispatch = useDispatch();
	const { loading, data, error } = useSelector((state: RootState) => state.swapi);
  

  useEffect(() => {
    dispatch(fetchSpeciesData());
  }, [dispatch]);

  if (loading) {
    return <Text>Loading...</Text>;
  }

  if (error) {
    return <Text>Error: {error}</Text>;
  }

	return (
<ScrollView>
      <View style={styles.container}>

      <Text style={styles.title}>Species</Text>
      {data &&
        data.results &&
        data.results.map((specie: any) => (
          <Card containerStyle={styles.card} key={specie.name}>
            <View style={styles.cardContent}>
              <Text style={styles.cardTitle}>{specie.name}</Text>
              <Text>Classification: {specie.classification}</Text>
              <Text>Designation: {specie.designation}</Text>
              <Text>Average Height: {specie.average_height}</Text>
              <Text>Skin Colors: {specie.skin_colors}</Text>
              <Text>Eye Colors: {specie.eye_colors}</Text>
              <Text>Average Lifespan: {specie.average_lifespan}</Text>
            </View>
          </Card>
        ))}
        </View>
    </ScrollView>
	);
};

export default Species;
